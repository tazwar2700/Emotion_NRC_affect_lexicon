# Emotion_NRC
 emotion classifiers
